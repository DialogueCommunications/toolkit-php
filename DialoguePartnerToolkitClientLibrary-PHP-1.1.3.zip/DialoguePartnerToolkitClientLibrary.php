<?php
/**
 * Dialogue PHP Partner Toolkit Library
 *
 * @package Dialogue\Toolkit\Sms
 * @version 1.1.3
 */
namespace Dialogue\Toolkit\Sms;

/**
 * Credentials object containing username and password.
 *
 * @property string $userName Username.
 * @property string $password Password.
 */
class Credentials
{
    private $userName;
    private $password;

    /**
     * Creates a new Credentials instance. You must provide your API username and password.
     *
     * @param string $userName Username.
     * @param string $password Password.
     */
    public function __construct($userName, $password)
    {
        $this->userName = $userName;
        $this->password = $password;
    }

    public function __get($name)
    {
        if ($name == "userName") {
            return $this->userName;
        } elseif ($name == "password") {
            return $this->password;
        }

        $trace = debug_backtrace();
        trigger_error(
            'Undefined property via __get(): ' . $name .
            ' in ' . $trace[0]['file'] .
            ' on line ' . $trace[0]['line'],
            E_USER_NOTICE
        );
        return null;
    }

    public function __set($name, $value)
    {
        if ($name == "userName") {
            if (!$value) {
                throw new \InvalidArgumentException(
                    "No userName provided."
                );
            }

            $this->userName = $value;
        } elseif ($name == "password") {
            if (!$value) {
                throw new \InvalidArgumentException(
                    "No password provided."
                );
            }

            $this->password = $value;
        } else {
            $trace = debug_backtrace();
            trigger_error(
                'Undefined property via __set(): ' . $name .
                ' in ' . $trace[0]['file'] .
                ' on line ' . $trace[0]['line'],
                E_USER_NOTICE
            );
        }
    }
}

/**
 * Client used for sending messages.
 *
 * @property string $endpoint Endpoint (host name) used for sending messages.
 * @property Credentials $credentials Credentials (username, password) used for sending messages.
 * @property string $path Path used for sending messages (normally you should not and don't need to modify this).
 * @property bool $secure Allows enabling (if true) or disabling (if false) secure communication. By default secure
 * communication is enabled and we strongly recommended that you don't change this property.
 */
class SendSmsClient
{
    private $endpoint;
    private $credentials;
    private $path = "/submit_sm";

    public $secure = true;

    /**
     * Creates a new SendSmsClient instance. You must provide your API endpoint and API credentials.
     *
     * @param string $endpoint API endpoint (host name) used for sending messages.
     * @param Credentials $credentials API credentials (username, password) used for sending messages.
     */
    public function __construct($endpoint, $credentials)
    {
        $this->credentials = $credentials;
        $this->endpoint = $endpoint;
    }

    public function __get($name)
    {
        if ($name == "endpoint") {
            return $this->endpoint;
        } elseif ($name == "credentials") {
            return $this->credentials;
        } elseif ($name == "path") {
            return $this->path;
        }

        $trace = debug_backtrace();
        trigger_error(
            'Undefined property via __get(): ' . $name .
            ' in ' . $trace[0]['file'] .
            ' on line ' . $trace[0]['line'],
            E_USER_NOTICE
        );
        return null;
    }

    public function __set($name, $value)
    {
        if ($name == "endpoint") {
            if (!$value) {
                throw new \InvalidArgumentException(
                    "No endpoint provided."
                );
            }

            $this->endpoint = $value;
        } elseif ($name == "credentials") {
            if (!$value) {
                throw new \InvalidArgumentException(
                    "No credentials provided."
                );
            }

            $this->credentials = $value;
        } elseif ($name == "path") {
            if (!$value) {
                throw new \InvalidArgumentException(
                    "No path provided."
                );
            }

            if ($value[0] != '/') {
                throw new \InvalidArgumentException(
                    "The path must start with '/'."
                );
            }

            $this->path = $value;
        } else {
            $trace = debug_backtrace();
            trigger_error(
                'Undefined property via __set(): ' . $name .
                ' in ' . $trace[0]['file'] .
                ' on line ' . $trace[0]['line'],
                E_USER_NOTICE
            );
        }
    }

    /**
     * Performs the message submission.
     *
     * @param SendSmsRequest $sendSmsRequest Request object containing message(s), recipient(s) and other
     * optional properties.
     * @return SendSmsResponse Response object containing a list of one or more submitted messages.
     * @throws \Exception Thrown if there is a networking or communication problem with the endpoint.
     */
    public function sendSms(SendSmsRequest $sendSmsRequest)
    {
        $ch = curl_init();
        curl_setopt($ch, CURLOPT_URL, ($this->secure ? "https://" : "http://") . $this->endpoint . $this->path);
        curl_setopt(
            $ch,
            CURLOPT_HTTPHEADER,
            array(
                'Content-Type: application/xml; charset=UTF-8'
            )
        );
        curl_setopt($ch, CURLOPT_HTTPAUTH, CURLAUTH_BASIC);
        curl_setopt($ch, CURLOPT_USERPWD, $this->credentials->userName . ":" . $this->credentials->password);
        curl_setopt($ch, CURLOPT_POST, 1);
        curl_setopt($ch, CURLOPT_POSTFIELDS, "" . $sendSmsRequest);
        curl_setopt($ch, CURLOPT_RETURNTRANSFER, 1);

        if ($this->secure) {
            curl_setopt($ch, CURLOPT_SSL_VERIFYHOST, true);
            curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, true);
            curl_setopt($ch, CURLOPT_CAINFO, __DIR__ . '/cacert.pem');
        }

        $xml = curl_exec($ch);
        $info = curl_getinfo($ch);
        curl_close($ch);

        $status = intval($info['http_code']);
        if ($status != 200) {
            throw new \Exception($xml, $status);
        }

        $response = new SendSmsResponse();
        $response->messages = array();

        $parser = xml_parser_create();
        xml_set_object($parser, $response);
        xml_set_element_handler($parser, 'startElement', null);
        xml_parse($parser, $xml);
        xml_parser_free($parser);

        return $response;
    }
}

/**
 * Request object containing message(s), recipient(s) and other optional properties.
 *
 * @property array|string $messages The message or messages list.
 * @property array|string $recipients The recipient or recipients list.
 * @property int $concatenationLimit By setting the concatenationLimit property, you enable long message concatenation.
 * If the length of any message exceeds the default character limit the messaging gateway will send multiple
 * concatenated messages up to the concatenation limit, after which the text is truncated. Concatenation works by
 * splitting and wrapping the message in packets or fragments, each fragment being prefixed by the current fragment
 * number and the total number of fragments. This allows the phone to know when it received all fragments and how to
 * reassemble the message even if fragments arrive out of order. The concatenation limit refers to the maximum number
 * of message fragments, not the number of characters, i.e. a concatenation limit of “3” means no more than 3 SMS
 * messages will be sent, which in total can contain up to 459 GSM-compatible characters. The concatenation overhead
 * is 7 characters, so 160 - 7 = 153 available characters per fragment x 3 = 459 total characters.
 * In the response you will find one Sms object for each message segment.
 * @property \DateTime $scheduleFor Use the scheduleFor property to delay sending messages until the specified date and
 * time. The property is of type DateTime and must be an instance of DateTimeKind.Utc so that time zone conversion is
 * possible. If the schedule date/time is in the past the message is sent immediately.
 * @property bool $confirmDelivery The property confirmDelivery can be set to true to enable tracking of message
 * delivery. If you enable confirmDelivery you must also set the replyPath property pointing to an HTTP event handler
 * that you implement. Optionally, set userKey to an arbitrary, custom identifier, which will be posted back to you.
 * You can use this to associate a message submission with a delivery report.
 * @property string $replyPath See property confirmDelivery.
 * @property string $userKey See property confirmDelivery.
 * @property string $sessionReplyPath The property sessionReplyPath points to an HTTP event handler that you have
 * implemented. The handler is invoked if the recipient replies to the message they have received. Optionally you can
 * specify the sessionId property, which will be posted back to you. You can use this to associate a message submission
 * with a reply.
 * @property string $sessionId See property sessionReplyPath.
 * @property string $userTag By setting the UserTag property you can tag messages. You can use this for billing
 * purposes when sending messages on behalf of several customers. The UserTag property must not exceed 50 characters;
 * longer values will make the submission fail.
 * @property \DateInterval $validityPeriod Use the ValidityPeriod property to specify the maximum message delivery
 * validity after which the message is discarded unless received. The property is of type TimeSpan (seconds and
 * milliseconds are ignored). If not set the default validity period is applied. The maximum validity period is 14 days,
 * if you specify a longer validity period 14 days will be used.
 */
class SendSmsRequest extends \ArrayObject
{
    private $messages;
    private $recipients;
    private $validityPeriod;

    public $sender;
    public $concatenationLimit;
    public $scheduleFor;
    public $confirmDelivery;
    public $replyPath;
    public $userKey;
    public $sessionReplyPath;
    public $sessionId;
    public $userTag;

    /**
     * Constructs a SendSmsRequest object with a message or list of messages and a recipient or list of recipient.
     *
     * @param array|string $messages The message or messages list.
     * @param array|string $recipients The recipient or recipients list.
     * @throws \InvalidArgumentException thrown when messages or recipients is null or empty.
     */
    public function __construct($messages, $recipients)
    {
        $this->messages = $messages;
        $this->recipients = $recipients;
    }

    public function __get($name)
    {
        if ($name == "messages") {
            return $this->messages;
        } elseif ($name == "recipients") {
            return $this->recipients;
        } elseif ($name == "validityPeriod") {
            return $this->validityPeriod;
        }

        $trace = debug_backtrace();
        trigger_error(
            'Undefined property via __get(): ' . $name .
            ' in ' . $trace[0]['file'] .
            ' on line ' . $trace[0]['line'],
            E_USER_NOTICE
        );
        return null;
    }

    public function __set($name, $value)
    {
        if ($name == "messages") {
            if (!is_array($value) && empty($value)) {
                throw new \InvalidArgumentException(
                    "No message provided."
                );
            }

            if (is_array($value) && empty($value)) {
                throw new \InvalidArgumentException(
                    "No messages provided."
                );
            }

            $this->messages = $value;
        } elseif ($name == "recipients") {
            if (!is_array($value) && empty($value)) {
                throw new \InvalidArgumentException(
                    "No recipient provided."
                );
            }

            if (is_array($value) && empty($value)) {
                throw new \InvalidArgumentException(
                    "No recipients provided."
                );
            }

            $this->recipients = $value;
        } elseif ($name == "validityPeriod") {
            if ($value && $value->y != 0) {
                throw new \InvalidArgumentException(
                    "Years not supported as unit."
                );
            }

            if ($value && $value->m != 0) {
                throw new \InvalidArgumentException(
                    "Months not supported as unit."
                );
            }

            $this->validityPeriod = $value;
        } else {
            $trace = debug_backtrace();
            trigger_error(
                'Undefined property via __set(): ' . $name .
                ' in ' . $trace[0]['file'] .
                ' on line ' . $trace[0]['line'],
                E_USER_NOTICE
            );
        }
    }

    /**
     * Returns an XML representation of this SendSmsRequest instance.
     *
     * @return string XML representation of this SendSmsRequest instance.
     */
    public function __toString()
    {
        $doc = new \DOMDocument();
        $root = $doc->createElement("sendSmsRequest");
        $doc->appendChild($root);

        if (is_array($this->messages)) {
            foreach ($this->messages as $message) {
                $el = $doc->createElement("X-E3-Message");
                $el->nodeValue = $message;
                $root->appendChild($el);
            }
        } else {
            $el = $doc->createElement("X-E3-Message");
            $el->nodeValue = $this->messages;
            $root->appendChild($el);
        }

        if (is_array($this->recipients)) {
            foreach ($this->recipients as $recipient) {
                $el = $doc->createElement("X-E3-Recipients");
                $el->nodeValue = $recipient;
                $root->appendChild($el);
            }
        } else {
            $el = $doc->createElement("X-E3-Recipients");
            $el->nodeValue = $this->recipients;
            $root->appendChild($el);
        }

        if ($this->sender) {
            $el = $doc->createElement("X-E3-Originating-Address");
            $el->nodeValue = $this->sender;
            $root->appendChild($el);
        }

        if ($this->concatenationLimit) {
            $el = $doc->createElement("X-E3-Concatenation-Limit");
            $el->nodeValue = $this->concatenationLimit;
            $root->appendChild($el);
        }

        if ($this->scheduleFor) {
            $el = $doc->createElement("X-E3-Schedule-For");
            $temp = new \DateTime(null, new \DateTimeZone("UTC"));
            $temp->setTimestamp($this->scheduleFor->getTimestamp());
            $temp->setTimezone(new \DateTimeZone("Europe/London"));
            $el->nodeValue = $temp->format("YmdHis");
            $root->appendChild($el);
        }

        if (!is_null($this->confirmDelivery)) {
            $el = $doc->createElement("X-E3-Confirm-Delivery");
            $el->nodeValue = $this->confirmDelivery ? "on" : "off";
            $root->appendChild($el);
        }

        if ($this->replyPath) {
            $el = $doc->createElement("X-E3-Reply-Path");
            $el->nodeValue = $this->replyPath;
            $root->appendChild($el);
        }

        if ($this->userKey) {
            $el = $doc->createElement("X-E3-User-Key");
            $el->nodeValue = $this->userKey;
            $root->appendChild($el);
        }

        if ($this->sessionReplyPath) {
            $el = $doc->createElement("X-E3-Session-Reply-Path");
            $el->nodeValue = $this->sessionReplyPath;
            $root->appendChild($el);
        }

        if ($this->sessionId) {
            $el = $doc->createElement("X-E3-Session-ID");
            $el->nodeValue = $this->sessionId;
            $root->appendChild($el);
        }

        if ($this->userTag) {
            $el = $doc->createElement("X-E3-User-Tag");
            $el->nodeValue = $this->userTag;
            $root->appendChild($el);
        }

        if ($this->validityPeriod) {
            $el = $doc->createElement("X-E3-Validity-Period");

            if ($this->validityPeriod->i != 0) {
                $el->nodeValue = (
                    $this->validityPeriod->d * 24 * 60
                    + $this->validityPeriod->h * 60
                    + $this->validityPeriod->i)
                    . "m";
            } elseif ($this->validityPeriod->h != 0) {
                $el->nodeValue = (
                    $this->validityPeriod->d * 24
                    + $this->validityPeriod->h)
                    . "h";
            } elseif ($this->validityPeriod->d >= 1 && $this->validityPeriod->d % 7 == 0) {
                $el->nodeValue = ($this->validityPeriod->d / 7) . "w";
            } else {
                $el->nodeValue = $this->validityPeriod->d > 0 ? $this->validityPeriod->d . "d" : "0m"; // <1m passed
            }

            $root->appendChild($el);
        }

        foreach ($this as $key => $value) {
            $el = $doc->createElement($key);
            $el->nodeValue = $value;
            $root->appendChild($el);
        }

        return $doc->saveXML();
    }
}

/**
 * Response object containing a list of one or more submitted messages.
 *
 * @property array $messages List of submitted messages.
 */
class SendSmsResponse
{
    public $messages = array();

    public function startElement($parser, $name, $attrs)
    {
        if ($name == "SMS") {
            $sms = new Sms();
            $sms->recipient = $attrs["X-E3-RECIPIENTS"];
            $sms->submissionReport = $attrs["X-E3-SUBMISSION-REPORT"];
            if ($attrs["X-E3-SUBMISSION-REPORT"] == "00") {
                $sms->id = $attrs["X-E3-ID"];
                $sms->successful = true;
            } else {
                $sms->errorDescription = $attrs["X-E3-ERROR-DESCRIPTION"];
                $sms->successful = false;
            }
            array_push($this->messages, $sms);
        }
    }
}

/**
 * Contains details of an individual submission.
 *
 * @property string $id Unique identifier if the submission was successful; null otherwise.
 * @property string $recipient Recipient of the submission.
 * @property string $submissionReport Outcome (status code) of the submission; "00" means successful.
 * @property string $errorDescription Error description if the submission failed; null otherwise.
 * @property bool $successful True if the submission was successful; false otherwise.
 */
class Sms
{
    public $id;
    public $recipient;
    public $submissionReport;
    public $errorDescription;
    public $successful;
}

/**
 * Allows parsing incoming message report POST requests.
 *
 * @property string $id Unique report identifier (not that of the original submission).
 * @property string $recipient The original recipient of the submission.
 * @property string $deliveryReport Delivery report value, 00 to 1F indicating a successful delivery, 20 to 3F
 * indicating a temporary error, 40 to 5F indicating a permanent error and 60 to 7F indicating a retry error.
 * @property-read State $state The delivery report value classified into State::DELIVERED, State::TEMPORARY_ERROR
 * or State::PERMANENT_ERROR.
 * @property-read boolean $successful The delivery report value classified into State::DELIVERED,
 * State::TEMPORARY_ERROR, State::PERMANENT_ERROR or State::RETRY_ERROR
 * @property string $userKey True if State is State.Delivered, false otherwise.
 * @property \DateTime $timestamp Date and time the message was received.
 * @property string $network Mobile operator network name.
 */
class SmsReport
{
    public $id;
    public $recipient;
    public $deliveryReport;
    public $userKey;
    public $timestamp;
    public $network;

    /**
     * Parses a report from the given string or from php://input (post data from the current request).
     * @param string $xml Input string (optional).
     * @return SmsReport The parsed SmsReport instance.
     */
    public static function getInstance($xml = null)
    {
        if (is_null($xml)) {
            $xml = file_get_contents('php://input');
        }
        $report = new SmsReport();
        $parser = xml_parser_create();
        xml_set_object($parser, $report);
        xml_set_element_handler($parser, 'startElement', null);
        xml_parse($parser, $xml);
        xml_parser_free($parser);
        return $report;
    }

    public function startElement($parser, $name, $attrs)
    {
        if ($name == "CALLBACK") {
            $this->id = $attrs["X-E3-ID"];
            $this->recipient = $attrs["X-E3-RECIPIENTS"];
            $this->deliveryReport = $attrs["X-E3-DELIVERY-REPORT"];
            $this->userKey = $attrs["X-E3-USER-KEY"];
            $this->timestamp = \DateTime::createFromFormat(
                "Y-m-d H:i:s",
                $attrs["X-E3-TIMESTAMP"],
                new \DateTimeZone("Europe/London")
            );
            $this->network = $attrs["X-E3-NETWORK"];
        }
    }

    public function __get($name)
    {
        if ($name == "state") {
            if (!$this->deliveryReport) {
                return State::UNDEFINED;
            } elseif ($this->deliveryReport[0] === "0" || $this->deliveryReport[0] === "1") {
                return State::DELIVERED;
            } elseif ($this->deliveryReport[0] === "2" || $this->deliveryReport[0] === "3") {
                return State::TEMPORARY_ERROR;
            } elseif ($this->deliveryReport[0] === "4" || $this->deliveryReport[0] === "5") {
                return State::PERMANENT_ERROR;
            } elseif ($this->deliveryReport[0] === "6" || $this->deliveryReport[0] === "7") {
                return State::RETRY_ERROR;
            } else {
                throw new \UnexpectedValueException("Unknown delivery report value: $this->deliveryReport");
            }
        } elseif ($name == "successful") {
            return $this->state == State::DELIVERED;
        }

        $trace = debug_backtrace();
        trigger_error(
            'Undefined property via __get(): ' . $name .
            ' in ' . $trace[0]['file'] .
            ' on line ' . $trace[0]['line'],
            E_USER_NOTICE
        );
        return null;
    }
}

/**
 * Classifies the delivery report into DELIVERED, TEMPORARY_ERROR, PERMANENT_ERROR or RETRY_ERROR
 */
class State
{
    /**
     * Undefined (null) state
     */
    const UNDEFINED = 0;
    /**
     * Message delivered
     */
    const DELIVERED = 1;
    /**
     * Temporary error but could still be delivered
     */
    const TEMPORARY_ERROR = 2;
    /**
     * Permanent error, message was not delivered
     */
    const PERMANENT_ERROR = 3;
    /**
     * Retry error, message was not delivered
     */
    const RETRY_ERROR = 4;
}

/**
 * Allows parsing incoming message reply POST requests.
 *
 * @property string $id Unique message identifier (not that of the original submission).
 * @property string $sender The original recipient of the submission (now the sender as it's a reply).
 * @property string $sessionId Optional SessionId parameters from submission. Can be used to associate unique
 * submissions with replies, even if the recipient is the same.
 * @property string $hexMessage The hex-encoded message text.
 * @property string $message The message text.
 * @property \DateTime $timestamp Date and time the message was received.
 * @property string $network Mobile operator network name.
 */
class SmsReply
{
    public $id;
    public $sender;
    public $sessionId;
    public $hexMessage;
    public $message;
    public $timestamp;
    public $network;

    /**
     * Parses a reply from the given string or from php://input (post data from the current request).
     *
     * @param string $xml Input string (optional).
     * @param string $charset Character set used for input (optional, defaults to UTF-8).
     * @return SmsReply The parsed SmsReply instance.
     */
    public static function getInstance($xml = null, $charset = "UTF-8")
    {
        if (is_null($xml)) {
            $xml = file_get_contents('php://input');
        }
        $reply = new SmsReply();
        $parser = xml_parser_create();
        xml_set_object($parser, $reply);
        xml_set_element_handler($parser, 'startElement', null);
        xml_parse($parser, $xml);
        xml_parser_free($parser);
        $reply->message = iconv("ISO-8859-15", $charset, pack("H*", $reply->hexMessage));
        return $reply;
    }

    public function startElement($parser, $name, $attrs)
    {
        if ($name == "CALLBACK") {
            $this->id = $attrs["X-E3-ID"];
            $this->sender = $attrs["X-E3-ORIGINATING-ADDRESS"];
            $this->sessionId = $attrs["X-E3-SESSION-ID"];
            $this->hexMessage = $attrs["X-E3-HEX-MESSAGE"];
            $this->timestamp = \DateTime::createFromFormat(
                "Y-m-d H:i:s.000000",
                $attrs["X-E3-TIMESTAMP"],
                new \DateTimeZone("Europe/London")
            );
            $this->network = $attrs["X-E3-NETWORK"];
        }
    }
}